import threading
import urllib2
from time import sleep
import SendKeys
import ImageGrab
import random

print "How many SILLY GAMES shall we open in this session?"
print "Enter 0 to keep entering until closed out."
times = input("How many games? ")
print "What name would you like to INFILTRATE with, Goat?"
print "Enter \"list\" to pick randomly from \"Names.txt\" in the same directory."
name = raw_input("Name? ")
print "OK, ready. PUT YOUR CURSOR inside the \"Game Pin\" box on \"kahoot.it\"."

typing = False
infinite_times = False
if times == 0:
	infinite_times = True
names = None
if name == "list":
	name_file = open("Names.txt", "r")
	names = name_file.read().replace("\r", "").strip("\n").split("\n")
	name_file.close()

def enter_game(pin):
	global name
	global typing
	global times
	print pin
	while typing:
		sleep(1)
	typing = True
	SendKeys.SendKeys(pin + "~")
	pixel = (0, 0, 0)
	while pixel != (255, 255, 255):
		screen = ImageGrab.grab()
		screen = screen.load()
		pixel = screen[200, 94]
		sleep(0)
	enter_name = name
	if name == "list":
		enter_name = random.choice(names)
	SendKeys.SendKeys("{TAB}" + enter_name + "~")
	sleep(0)
	SendKeys.SendKeys("^t")
	sleep(0)
	SendKeys.SendKeys("kahoot.it~")
	changedpixel = (-1, -1, -1)
	# Wait till the page is fully loaded, we'll know when the color changes
	while changedpixel != (65, 196, 221):
		screen = ImageGrab.grab()
		screen = screen.load()
		changedpixel = screen[200,200]
		sleep(0)
	while changedpixel == (65, 196, 221):
		screen = ImageGrab.grab()
		screen = screen.load()
		changedpixel = screen[200,200]
		sleep(0)
	SendKeys.SendKeys("{TAB}")
	times -= 1
	typing = False

def check_pin(pin):
	global typing
	try:
		check = urllib2.urlopen("https://kahoot.it/reserve/test/" + pin).read()
	except urllib2.HTTPError, e:
		sleep(0)
		return
	if check == "true":
		enter_game(pin)

file = open("LastDigit.txt", "r")
checking = int(file.read()) + 1
file.close()
running = True

while running:
	if not infinite_times:
		if times <= 0:
			running = False
	if threading.activeCount() < 200:
		attempt = threading.Thread(target=check_pin, args=(str(checking),))
		attempt.start()
		checking += 1
		if checking > 999999:
			checking = 0
		file = open("LastDigit.txt", "w")
		file.write(str(checking))
		file.close()
	else:
		sleep(1)
